public class User {
    public String name;
    public String email;
    public String contact;
    public String password;
}
